import React from 'react';

import AppContactUs from '../components/contactUs/contact.js';
import AppPricing from '../components/categories/pricing.js';


function AppContact() {
  return (
    <div className="categories">
      <h1>Contact us</h1>
    
      <AppContactUs/>
    </div>
  );
}

export default AppContact;