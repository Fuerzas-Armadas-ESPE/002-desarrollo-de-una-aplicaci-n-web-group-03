// pages/api/send-email.js (Este archivo debe estar en el directorio "pages/api" de tu proyecto)
import sgMail from '@sendgrid/mail';
import dotenv from 'dotenv';

dotenv.config();

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { fullname, email, telephone, subject, message } = req.body;

    const msg = {
      to: 'lanchado10@gmail.com',
      from: {
        name: 'Contacto desde la web',
        email: process.env.FROM_EMAIL,
      },
      subject: subject,
      text: `Nombre: ${fullname}\nEmail: ${email}\nTeléfono: ${telephone}\n\nMensaje: ${message}`,
      html: `<p>Nombre: ${fullname}</p><p>Email: ${email}</p><p>Teléfono: ${telephone}</p><p>Mensaje: ${message}</p>`,
    };

    try {
      await sgMail.send(msg);
      console.log('Email sent');
      res.status(200).json({ message: 'Email sent successfully' });
    } catch (error) {
      console.error(error);
      console.log('Email not sent');
      res.status(500).json({ error: 'Error sending email' });
    }
  } else {
    res.status(405).json({ error: 'Method not allowed' });
  }
}
