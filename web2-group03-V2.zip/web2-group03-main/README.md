# Group 03
#Karla Alejandra Ansatuña Andrade
#Alex Fernando Trejo Duque
#NRC: 14564

#1)npm install

#2)npm install react-router-dom

#3)npm install @sendgrid/mail dotenv

#4)crear un .env en la carpeta server y poner la informacion que esta en el pdf

#EJECUCION

#1)npm start        ->en la raiz del directorio

#2)node server.js   ->debe abrir el directorio de server



